package Assignment0;
import gradingTools.comp410f19.assignment0.testcases.Assignment0Suite;

public class RunTests {
  public static void main(String[] args){
    Assignment0Suite.main(args);
  }
}