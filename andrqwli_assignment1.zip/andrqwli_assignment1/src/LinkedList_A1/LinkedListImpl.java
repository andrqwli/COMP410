/**
 * COMP 410
 *See inline comment descriptions for methods not described in interface.
 *
*/
package LinkedList_A1;

public class LinkedListImpl implements LIST_Interface {
  Node sentinel; //this will be the entry point to your linked list (the head)
  int numElts = 0;
  
  public LinkedListImpl(){//this constructor is needed for testing purposes. Please don't modify!
    sentinel=new Node(0); //Note that the root's data is not a true part of your data set!
  }
  
  //implement all methods in interface, and include the getRoot method we made for testing purposes. Feel free to implement private helper methods!
  
  public Node getRoot(){ //leave this method as is, used by the grader to grab your linkedList easily.
    return sentinel;
  }

@Override
public boolean insert(double elt, int index) {
	if (index > this.numElts || index < 0) {
		return false;
	}
	Node node = new Node(elt);
	if (numElts == 0) {
		this.sentinel.next = node;
		this.sentinel.prev = node;
		node.next = this.sentinel;
		node.prev = this.sentinel;
		numElts++;
		return true;
	}
	
	if (index == 0) {
		node.prev = this.sentinel;
		this.sentinel.next.prev = node;
		node.next = this.sentinel.next;
		this.sentinel.next = node;
		numElts++;
		return true;
	}
	Node curr = this.sentinel.next;
	if (index == numElts) {
		for (int i = 0; i < index - 1; i++) {
			curr = curr.next;
		}
		curr.next = node;
		node.prev = curr;
		node.next = this.sentinel;
		this.sentinel.prev = node;
		numElts++;
		return true;
	}
	
	
	for (int i = 0; i < index - 1; i++) {
		curr = curr.next;
	}
	
	curr.next.prev = node;
	node.prev = curr;
	node.next = curr.next;
	curr.next = node;
	numElts++;
	return true;
	
}

@Override
public boolean remove(int index) {
	if (index > this.numElts - 1 || index < 0) {
		return false;
	}
	Node curr = this.sentinel.next;
	for (int i = 0; i < index; i++) {
		curr = curr.next;
	}
	curr.prev.next = curr.next;
	curr.next.prev = curr.prev;
	this.numElts--;
	return true;
}

@Override
public double get(int index) {
	if (index > this.numElts - 1 || index < 0) {
		return Double.NaN;
	}
	Node curr = this.sentinel.next;
	for (int i = 0; i < index; i++) {
		curr = curr.next;
	}
	return curr.getData();
}

@Override
public int size() {
	return this.numElts;
}

@Override
public boolean isEmpty() {
	return this.numElts == 0;
}

@Override
public void clear() {
	this.sentinel.next = null;
	this.sentinel.prev = null;
	this.numElts = 0;
}
}
