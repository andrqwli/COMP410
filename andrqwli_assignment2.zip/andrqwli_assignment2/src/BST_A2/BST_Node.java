package BST_A2;

public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  
  BST_Node(String data){ this.data=data; }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }

  // --- end used for testing -------------------------------------------

  
  // --- fill in these methods ------------------------------------------
  //
  // at the moment, they are stubs returning false 
  // or some appropriate "fake" value
  //
  // you make them work properly
  // add the meat of correct implementation logic to them

  // you MAY change the signatures if you wish...
  // make the take more or different parameters
  // have them return different types
  //
  // you may use recursive or iterative implementations

  
  public boolean containsNode(String s) {
	  if (this.data.compareTo(s) == 0) {
		  return true;
	  } else if (this.data.compareTo(s) > 0) {
		  if (this.getLeft() == null) {
			  return false;
		  } else {
			  return this.getLeft().containsNode(s);
		  }
	  } else if (this.data.compareTo(s) < 0) {
		  if (this.getRight() == null) {
			  return false;
		  } else {
			  return this.getRight().containsNode(s);
		  }
	  }
	  return false;
  }
  
  public boolean insertNode(String s) { 
	  if (this.data.compareTo(s) == 0) {
		  return false;
	  } else if (this.data.compareTo(s) > 0) {
		  if (this.getLeft() == null) {
			  this.left = new BST_Node(s);
			  return true;
		  }
		  return this.getLeft().insertNode(s);
	  } else if (this.data.compareTo(s) < 0) {
		  if (this.getRight() == null) {
			  this.right = new BST_Node(s);
			  return true;
		  }
		  return this.getRight().insertNode(s);
	  }
	  return false;
  }
  
  public boolean removeNode(String s, BST_Node parent) {                                       // sort which branch to go down
	  if (this.data.compareTo(s) > 0) {           // go left if s is less than the string
		  if (this.getLeft() != null) {
			  return this.getLeft().removeNode(s, this);
		  } else {
			  return false;
		  }
	  } else if (this.data.compareTo(s) < 0) {   
		  if (this.getRight() != null) {
			  return this.getRight().removeNode(s, this);
		  } else {
			  return false;
		  }
	  } else {
		  if (this.getLeft() != null && this.getRight() != null) {
			  data = right.findMin().getData();
			  right.removeNode(data, this);
		  } else if (parent.getLeft() == this) {
			  parent.left = (parent.left != null) ? left : right;
		  } else if (parent.getRight() == this) {
			  parent.right = (left != null) ? left : right;
		  }
		  return true;
	  }
  }
  
  public BST_Node findMin() { 
	  if (this.getLeft() == null) {
		  return this;
	  } else {
		  return this.getLeft().findMin();
	  }
  }
  
  public BST_Node findMax() { 
	  if (this.getRight() == null) {
		  return this;
	  } else {
		  return this.getRight().findMax();
	  }
  }
  
  public int getHeight() { 
	  if (this.getLeft() == null && this.getRight() == null) {
		  return 0;
	  } else {
		  int lHeight = 0;
		  int rHeight = 0;
		  
		  if (this.getLeft() != null) {
			  lHeight = this.getLeft().getHeight();
		  }
		  if (this.getRight() != null) {
			  rHeight = this.getRight().getHeight();
		  }
		  
		  if (lHeight > rHeight) {
			  return lHeight + 1;
		  } else {
			  return rHeight + 1;
		  }
	  }
  }
  

  // --- end fill in these methods --------------------------------------


  // --------------------------------------------------------------------
  // you may add any other methods you want to get the job done
  // --------------------------------------------------------------------
  
  public String toString(){
    return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
            +",Right: "+((this.right!=null)?right.data:"null");
  }
}