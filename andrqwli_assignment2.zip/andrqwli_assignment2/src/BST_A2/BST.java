package BST_A2;

public class BST implements BST_Interface {
  public BST_Node root;
  int size;
  
  public BST(){ size=0; root=null; }
  
  @Override
  //used for testing, please leave as is
  public BST_Node getRoot(){ return root; }

@Override
public boolean insert(String s) {
	if (this.getRoot() == null) {
		this.root = new BST_Node(s);
		this.size++;
		return true;
	} else {
		this.size++;
		return this.getRoot().insertNode(s);
	}
	
}

@Override
public boolean remove(String s) {
	if (this.getRoot() == null || this.size == 0) {
		return false;
	} else if (this.getRoot().getData().compareTo(s) == 0) {
		size--;
		BST_Node tempRoot = new BST_Node("");
		tempRoot.left = root;
		boolean result = root.removeNode(this.getRoot().data, tempRoot);
		root = tempRoot.getLeft();
		return result;
	} else {
		this.size--;
		return root.removeNode(s, null);
	}
}

@Override
public String findMin() {
	if (this.size == 0) {
		return null;
	}
	return this.getRoot().findMin().getData();
}

@Override
public String findMax() {
	if (this.size == 0) {
		return null;
	}
	return this.getRoot().findMax().getData();
}

@Override
public boolean empty() {
	return (size == 0 || this.getRoot() == null);
}

@Override
public boolean contains(String s) {
	if (this.size == 0 || this.getRoot() == null) {
		return false;
	} else {
		return this.getRoot().containsNode(s);
	}
}

@Override
public int size() {
	return this.size;
}

@Override
public int height() {
	if (this.size == 0 || this.getRoot() == null) {
		return -1;
	} else {
		return this.getRoot().getHeight();
	}
}

}